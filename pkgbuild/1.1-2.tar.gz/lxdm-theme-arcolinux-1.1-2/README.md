# LXDM Arch Linux Theme

Modified version of the original [Simple Arch Linux Theme for LXDM].

# Changes

- Added back user, session manager, keyboard layout and language selections plus the exit menu
- Added a GTK3 version

# License

These works are licensed Creative Commons. 
For full license details, refer to the COPYING file.
For attribution, refer to the AUTHORS file.

[Simple Arch Linux Theme for LXDM]: http://allanmcrae.com/2011/08/simple-arch-linux-theme-for-lxdm/
