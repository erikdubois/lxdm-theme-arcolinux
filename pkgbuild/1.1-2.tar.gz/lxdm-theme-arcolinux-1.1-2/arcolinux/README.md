# License

These works are licensed Creative Commons. 
For full license details, refer to the COPYING file.
For attribution, refer to the AUTHORS file.
